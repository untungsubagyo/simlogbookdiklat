<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Kategori Kegiatan</h1>
    <form action="<?php echo e(route('kategori_kegiatan.update', $kategoriKegiatan->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Nama Kategori</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($kategoriKegiatan->name); ?>" required>
        </div>
        <div class="mb-3">
            <label for="parent_id" class="form-label">Parent Kategori</label>
            <select class="form-control" id="parent_id" name="parent_id">
                <option value="">None</option>
                <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($parent->id); ?>" <?php echo e($kategoriKegiatan->parent_id == $parent->id ? 'selected' : ''); ?>><?php echo e($parent->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/kategori_kegiatans/edit.blade.php ENDPATH**/ ?>