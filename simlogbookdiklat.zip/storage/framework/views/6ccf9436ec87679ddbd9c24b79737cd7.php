<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Detail Guru</title>
</head>
<body>

<div class="container">
    <h1>Detail Guru</h1>
    <div class="card">
        <div class="card-header">
            <h3><?php echo e($usersData->name); ?></h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="profile_photo">Profile Photo</label>
                <div>
                    <?php if($usersData->profile_photo): ?>
                        <img src="<?php echo e(Storage::url($usersData->profile_photo)); ?>" alt="Profile Photo" width="150">
                    <?php else: ?>
                        <p>No Photo</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <p><?php echo e($usersData->email); ?></p>
            </div>
            <div class="form-group">
                <label for="created_at">Created At</label>
                <p><?php echo e($usersData->created_at); ?></p>
            </div>
            <div class="form-group">
                <label for="updated_at">Updated At</label>
                <p><?php echo e($usersData->updated_at); ?></p>
            </div>
            <a href="<?php echo e(route('manage_users.edit', $usersData->id)); ?>" class="btn btn-warning">Edit</a>
            <a href="<?php echo e(route('manage_users.index')); ?>" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
</div>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/manage_users/show.blade.php ENDPATH**/ ?>