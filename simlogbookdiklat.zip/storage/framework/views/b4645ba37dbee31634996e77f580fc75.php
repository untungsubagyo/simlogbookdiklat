<?php if(Auth::user()->role_id == 2): ?>
   <?php $__env->startSection('sidebar'); ?>
      
   <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
   <h1>Profil Saya</h1>
   <nav>
      <ol class="breadcrumb">
         <li class="breadcrumb-item active">Profile Saya</li>
      </ol>
   </nav>
</div>

<?php if($errors->any()): ?>
   <ul class="alert alert-danger" style="padding-left: 2rem;">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </ul>
<?php endif; ?>

<div class="row">
   <?php if(Session('message')): ?>
      <div class="alert alert-success"><?php echo e(Session('message')); ?></div>
   <?php endif; ?>
   <div class="col-xl-4">
      <div class="card">
         <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
            <?php if(isset($dataProfile->profile_photo)): ?>
               <img src="<?php echo e(Storage::url($dataProfile->profile_photo)); ?>"
                  style="width: 8rem; height: 8rem; object-fit: cover;" alt="Profile" class="rounded-circle">
            <?php else: ?>
               <div
                  style="width: 8rem; height: 8rem; border-radius: 50%; background-color: gray; text-align: center; line-height: 8rem; font-size: 1.8rem; color: white">
                  <?php echo e(substr(Auth::user()->name, 0, 2)); ?>

               </div>
            <?php endif; ?>

            <h2><?php echo e($dataProfile->name); ?></h2>
            <p><?php echo e($dataProfile->email); ?></p>
         </div>
      </div>
   </div>

   <div class="col-xl-8">
      <div class="card">
         <div class="card-body pt-3">
            <ul class="nav nav-tabs nav-tabs-bordered">
               <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab"
                     data-bs-target="#profile-overview">Overview</button>
               </li>
               <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
               </li>
            </ul>
            <div class="tab-content pt-2">
               <div class="tab-pane fade profile-overview <?php echo e($errors->any() ? '' : 'show active'); ?>" id="profile-overview">
                  <h5 class="card-title">Detail Profil</h5>

                  <div class="row mb-2">
                     <div class="col-lg-3 col-md-4 label fw-bold">Nama</div>
                     <div class="col-lg-9 col-md-8"><?php echo e($dataProfile->name); ?></div>
                  </div>

                  <div class="row mb-2">
                     <div class="col-lg-3 col-md-4 label fw-bold">Email</div>
                     <div class="col-lg-9 col-md-8"><?php echo e($dataProfile->email); ?></div>
                  </div>

                  <div class="row mb-2">
                     <div class="col-lg-3 col-md-4 label fw-bold">Tipe Akun</div>
                     <div class="col-lg-9 col-md-8"><?php echo e($dataProfile->role_id == 1 ? 'Admin' : 'Guru'); ?></div>
                  </div>

                  <?php if($dataProfile->role_id == 2): ?>
                     <div class="row mb-2">
                        <div class="col-lg-3 col-md-4 label fw-bold">NIP</div>
                        <div class="col-lg-9 col-md-8"><?php echo e($dataGuru[0]->NIP); ?></div>
                     </div>
                     <div class="row mb-2">
                        <div class="col-lg-3 col-md-4 label fw-bold">Golongan</div>
                        <div class="col-lg-9 col-md-8"><?php echo e($dataGuru[0]->golongan); ?></div>
                     </div>
                     <div class="row mb-2">
                        <div class="col-lg-3 col-md-4 label fw-bold">Pangkat</div>
                        <div class="col-lg-9 col-md-8"><?php echo e($dataGuru[0]->pangkat); ?></div>
                     </div>
                  <?php endif; ?>
               </div>

               <div class="tab-pane fade profile-edit pt-3 <?php echo e($errors->any() ? 'show active' : ''); ?>" id="profile-edit">
                  <form action="<?php echo e(route('my_profile.update')); ?>" method="post" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('put'); ?>
                     <div class="row mb-3">
                        <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Profile Image</label>
                        <div class="col-md-8 col-lg-9">
                           <div id="trigger-input-img"
                              style="cursor: pointer; width: 8rem; height: 8rem; background-color: gray; text-align: center; line-height: 8rem; color: white">
                              <input hidden type="file" name="profile_photo" id="input-img"
                                 accept=".png,.jpg,.jpeg,.webp">
                              <input hidden type="text" value="false" name="request-del-profile"
                                 id="request-del-profile">
                              <img id="img-preview" src="<?php echo e(Storage::url($dataProfile->profile_photo)); ?>"
                                 style="width: 8rem; height: 8rem; object-fit: cover;" alt="Profile">
                              <span id="fallback-text">upload photo</span>
                           </div>

                           <div class="pt-2">
                              <button type="button" id="trigger-input-img" class="btn btn-primary btn-sm"
                                 title="Upload new profile image"><i class="bi bi-upload"></i></button>
                              <button id="set-req-del-true" type="button" class="btn btn-danger btn-sm"
                                 title="Remove my profile image"><i class="bi bi-trash"></i></button>
                           </div>
                        </div>
                     </div>

                     <div class="row mb-3">
                        <label for="name" class="col-md-4 col-lg-3 col-form-label">Name</label>
                        <div class="col-md-8 col-lg-9">
                           <input required name="name" type="text" class="form-control" id="nama"
                              value="<?php echo e($dataProfile->name); ?>">
                        </div>
                     </div>

                     <div class="row mb-3">
                        <label for="email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                        <div class="col-md-8 col-lg-9">
                           <input required name="email" type="email" class="form-control" id="email"
                              value="<?php echo e($dataProfile->email); ?>">
                        </div>
                     </div>

                     <div class="row mb-3">
                        <label for="password-input" class="col-md-4 col-lg-3 col-form-label">
                           Password <br> 
                           <span style="font-size: 0.8rem">kosongkan jika tidak ingin mengubah</span> 
                        </label>
                        <div class="col-md-8 col-lg-9">
                           <input type="password" name="password" id="password-input" class="form-control">
                        </div>
                     </div>

                     <div class="row mb-3">
                        <label for="password_confirmation" class="col-md-4 col-lg-3 col-form-label">Confirm Password</label>
                        <div class="col-md-8 col-lg-9">
                           <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                        </div>
                     </div>

                     <?php if($dataProfile->role_id == 2): ?>
                        <!-- id_guru -->
                        <input type="text" hidden name="idg" value="<?php echo e($dataGuru[0]->id_guru); ?>">
                        
                        <div class="row mb-3">
                           <label for="NIP" class="col-md-4 col-lg-3 col-form-label">NIP</label>
                           <div class="col-md-8 col-lg-9">
                              <input name="NIP" type="text" class="form-control" id="NIP" value="<?php echo e($dataGuru[0]->NIP); ?>">
                           </div>
                        </div>

                        <div class="row mb-3">
                           <label for="golongan" class="col-md-4 col-lg-3 col-form-label">Golongan</label>
                           <div class="col-md-8 col-lg-9">
                              <select class="form-control" id="golongan_id" name="golongan_id" required>
                              <?php $__currentLoopData = $dataGolongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($gol->id); ?>" <?php echo e($gol->id == $dataGuru[0]->gol_id ? 'selected' : ''); ?>>
                                    <?php echo e($gol->golongan); ?> - <?php echo e($gol->pangkat); ?>

                                 </option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>
                     <?php endif; ?>
                     <div class="text-center">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
   window.onload = () => {
      const inputImage = document.getElementById('input-img')
      const reqDelInp = document.getElementById('request-del-profile')
      const fallbackText = document.getElementById('fallback-text')
      const imgPreview = document.getElementById('img-preview')
      const confirmPass = document.getElementById('password_confirmation')
      
      reqDelInp.value = 'false'

      // const dataT = new DataTransfer()
      // fetch('')
      //    .then(data => data.blob())
      //    .then(img => {
      //       dataT.items.add(new File([img], ''.replace('/storage/profile_photos/', ''), { type: img.type }))
      //       inputImage.files = dataT.files
      //    })

      confirmPass.disabled = true
      document.getElementById('password-input').addEventListener('input', ev => {
         if (ev.target.value.length > 0) {
            confirmPass.disabled = false
         } else {
            confirmPass.disabled = true
         }
      })

      document.querySelectorAll('#trigger-input-img').forEach(el => {
         el.addEventListener('click', () => {
            inputImage.click()
         })
      })

      inputImage.addEventListener('change', ev => {
         const files = ev.target.files

         if (files.length > 0) {
            reqDelInp.value = 'false'
            imgPreview.hidden = false
            fallbackText.hidden = true
            imgPreview.src = URL.createObjectURL(ev.target.files[0]);
         } else {
            // inputImage.files = dataT.files
            imgPreview.src = '<?php echo e(Storage::url($dataProfile->profile_photo)); ?>'
         }
      })

      document.getElementById('set-req-del-true').addEventListener('click', () => {
         reqDelInp.value = 'true'
         imgPreview.hidden = true
         fallbackText.hidden = false
      })

      fallbackText.hidden = '<?php echo e(isset($dataProfile->profile_photo)); ?>'
      imgPreview.hidden = '<?php echo e(!isset($dataProfile->profile_photo)); ?>'
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.guru.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/my-profile.blade.php ENDPATH**/ ?>