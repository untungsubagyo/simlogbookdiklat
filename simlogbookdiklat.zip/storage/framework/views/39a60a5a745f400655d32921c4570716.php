<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Tambah Data Guru</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Guru</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section guru">
        <div class="col-lg-12">
            <form action="<?php echo e(route('manage_guru.store')); ?>" method="POST" class="row g-3 needs-validation" novalidate>
                <?php echo csrf_field(); ?>
                <div class="col-6">
                    <div class="form-group">
                        <label for="NIP">
                            NIP
                        </label>
                        <input type="text" class="form-control" id="NIP" name="NIP" value="<?php echo e(old('NIP')); ?>" required>
                        <div class="invalid-feedback">Please, enter your name!</div>
                    </div>
                    <div class="form-group">
                        <label for="name">
                            Nama
                        </label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                        <div class="invalid-feedback">Please, enter your name!</div>
                    </div>
                    <div class="form-group">
                        <label for="golongan_id">Golongan</label>
                        <select class="form-control" id="golongan_id" name="golongan_id" required>
                            <option value="">Pilih Golongan</option>
                            <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gol->id); ?>"><?php echo e($gol->golongan); ?> - <?php echo e($gol->pangkat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                        <div class="invalid-feedback">Please, enter your email!</div>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div class="invalid-feedback">Please, enter your password!</div>
                    </div>
                    <div class="form-group mt-4">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>  
            </form>
        </div>
    </section>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/manage-guru/form.blade.php ENDPATH**/ ?>