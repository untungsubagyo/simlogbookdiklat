<?php $__env->startSection('body-content'); ?>
	<?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/layouts/home-layout.blade.php ENDPATH**/ ?>