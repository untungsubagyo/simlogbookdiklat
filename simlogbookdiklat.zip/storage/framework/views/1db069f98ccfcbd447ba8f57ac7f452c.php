<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Kelola Guru</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Kelola Guru</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section guru">
        <div class="col-lg-12">
            <a href="<?php echo e(route('manage_guru.create')); ?>" class="btn btn-primary">Tambah</a>

            <?php if(session('success')): ?>
                <div class="alert alert-success mt-3">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <table class="table datatable table-stripped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIP</th>
                        <th>Nama</th>
                        <th>Golongan</th>
                        <th>Email</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($data->NIP); ?></td>
                            <td><?php echo e($data->name_guru); ?></td>
                            <td><?php echo e($data->golongan); ?> : <?php echo e($data->pangkat); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td>
                                
                                <a href="<?php echo e(route('manage_guru.edit', $data->id)); ?>" class="btn btn-warning">Edit</a>
                                <button class="btn btn-danger" onclick="confirmDelete('<?php echo e($data->id); ?>')">Delete</button>
                                <form id="delete-form-<?php echo e($data->id); ?>" action="<?php echo e(route('manage_guru.destroy', $data->id)); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center alert alert-danger">Data Guru masih Kosong</td>
                            </tr>
                        <?php endif; ?>
                </tbody>
            </table>
        </div>

        <script>
            function confirmDelete(id) {
                Swal.fire({
                    title: 'Apakah Anda yakin?',
                    text: "Anda tidak akan dapat mengembalikan ini!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        document.getElementById('delete-form-' + id).submit();
                    }
                });
            }
        </script>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/manage-guru/index.blade.php ENDPATH**/ ?>