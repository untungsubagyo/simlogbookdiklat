<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Kategori Kegiatan</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
            <li class="breadcrumb-item active">Kategori Kegiatan</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<div class="container">
    <a href="<?php echo e(route('kategori_kegiatan.create')); ?>" class="btn btn-primary mb-3">Tambah Kategori</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Parent</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $kategoriKegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($kategori->name); ?></td>
                <td><?php echo e($kategori->parent ? $kategori->parent->name : '-'); ?></td>
                <td>
                    <a href="<?php echo e(route('kategori_kegiatan.edit', $kategori->id)); ?>" class="btn btn-warning">Edit</a>
                    <button class="btn btn-danger" onclick="confirmDelete('<?php echo e($kategori->id); ?>')">Delete</button>
                    <form id="delete-form-<?php echo e($kategori->id); ?>" action="<?php echo e(route('kategori_kegiatan.destroy', $kategori->id)); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Anda tidak akan dapat mengembalikan ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + id).submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/kategori_kegiatans/index.blade.php ENDPATH**/ ?>