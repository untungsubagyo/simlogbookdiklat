<?php $__env->startSection('content'); ?>
<div class="pagetitle">
	<h1>Dashboard</h1>
	<nav>
		<ol class="breadcrumb">
			<li class="breadcrumb-item active">Dashboard</li>
		</ol>
	</nav>
</div><!-- End Page Title -->

<section class="section dashboard">
	<h1 class="text-3xl font-semibold">
		Selamat Datang
		<span class="fw-bold">
			<?php echo e($userdata->name); ?>

		</span>
	</h1>

	<div class="col-lg-8 w-100">
		<div class="row">
			<div class="col-xxl-4 col-md-6">
				<div class="card info-card sales-card">
					<div class="card-body">
						<h5 class="card-title">Banyak Guru <span>| Total</span></h5>
						<div class="d-flex align-items-center">
							<div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
								<i class="bi bi-people"></i>
							</div>
							<div class="ps-3">
								<h6><?php echo e($guruCounts); ?></h6>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xxl-4 col-md-6">
				<div class="card info-card revenue-card">
					<div class="card-body">
						<h5 class="card-title">Banyak Diklat <span>| Total</span></h5>
						<div class="d-flex align-items-center">
							<div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
								<i class="bi bi-book"></i>
							</div>
							<div class="ps-3">
								<h6><?php echo e($diklatCounts); ?></h6>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xxl-4 col-xl-12">
				<div class="card info-card customers-card">
					<div class="card-body">
						<h5 class="card-title">Rata-Rata Data Diklat <span>| per-guru</span></h5>

						<div class="d-flex align-items-center">
							<div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
								<i class="bi bi-graph-up"></i>
							</div>
							<div class="ps-3">
								<h6><?php echo e($averageDiklatCount); ?></h6>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="mb-5 mt-3" style="display: flex; align-items: center; justify-content: space-between">
		<h3 class="w-75" >Daftar Diklat Guru</h3>
		<?php if(!isset($dataDiklat['searchNotFound'])): ?>
			<?php if($dataDiklat->count() > 0): ?>
				<form id="search-diklat" style='width: 70%'>
					<input type="text" name="search" id="search-input" value="<?php echo e(request()->has('search') ? request()->get('search') : ''); ?>" placeholder="Cari nama diklat atau pemilik diklat" class="form-control">
				</form>
			<?php endif; ?>
		<?php else: ?>
			<form id="search-diklat" style='width: 70%'>
				<input type="text" name="search" id="search-input" placeholder="Cari nama diklat atau pemilik diklat" class="form-control">
			</form>
		<?php endif; ?>
	</div>
	
	<div class="col" id="data-diklat-container">
		<?php if(!isset($dataDiklat['searchNotFound'])): ?>
			<?php if($dataDiklat->count() > 0): ?>
				<?php $__currentLoopData = $dataDiklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $diklat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="w-100" id="data-diklat" data-pemilik="<?php echo e($diklat->username); ?>" data-namaDiklat="<?php echo e($diklat->nama_diklat); ?>">
						<div class="card p-2">
							<div class="card-body">
								<h5 style="line-height: .3rem" class="card-title">
									Data Diklat
									<strong>
										<?php echo e($diklat->nama_diklat); ?>

									</strong>
								</h5>
								<p style="line-height: .3rem" class="mb-4 text-black-50">Pemilik <strong><?php echo e($diklat->username); ?></strong></p>
								<p style="line-height: .3rem" class="mb-4 text-black-50">NIP <strong><?php echo e($diklat->NIP); ?></strong></p>
								<div style="display: flex; justify-content: space-between; align-items: flex-end">
									<a href="<?php echo e(route('diklat.show', $diklat->id)); ?>" class="btn btn-primary">Lihat</a>
									<p class="text-black-50 mb-0">
										Terakhir Diubah
										<span> | <?php echo e($diklat->updated_at); ?></span>
									</p>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<h5 class="text-center">
					Belum Ada Guru Yang Mencatat Diklat Nya
				</h5>
			<?php endif; ?>
		<?php else: ?>
			<h5 class="text-center">
				Data Diklat Tidak Di Temukan
			</h5>
		<?php endif; ?>

		<!-- pagination navigate -->
		<div style="display: flex; justify-content: center; align-items: center;">
			<ul class="pagination">
				<li class="page-item">
					<a href="<?php echo e($dataDiklat->url(1)); ?>" class="page-link">First</a>
				</li>
				<li class="page-item">
					<?php if($dataDiklat->previousPageUrl() == null): ?>
						<a href="#" class="page-link disabled">Previous</a>
					<?php else: ?>
						<a href="<?php echo e($dataDiklat->previousPageUrl()); ?>" class="page-link">Previous</a>
					<?php endif; ?>
				</li>
				<?php
					$startPage = max($dataDiklat->currentPage() - 2, 1);
					$endPage = min($dataDiklat->currentPage() + 2, $dataDiklat->lastPage());
				?>
				<?php if($startPage > 1): ?>
					<li class="page-item">
						<a href="<?php echo e($dataDiklat->url(1)); ?>" class="page-link">1</a>
					</li>
					<?php if($startPage > 2): ?>
						<li class="page-item">
							<span class="pagination-ellipsis">...</span>
						</li>
					<?php endif; ?>
				<?php endif; ?>
				<?php $__currentLoopData = range($startPage, $endPage); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="page-item">
						<a href="<?php echo e($dataDiklat->url($page)); ?>" class="page-link"><?php echo e($page); ?></a>
					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php if($endPage < $dataDiklat->lastPage()): ?>
					<?php if($endPage < $dataDiklat->lastPage() - 1): ?>
						<li class="page-item">
							<span class="pagination-ellipsis">...</span>
						</li>
					<?php endif; ?>
					<li class="page-item">
						<a href="<?php echo e($dataDiklat->url($dataDiklat->lastPage())); ?>" class="page-link"><?php echo e($dataDiklat->lastPage()); ?></a>
					</li>
				<?php endif; ?>
				<li class="page-item">
					<?php if($dataDiklat->nextPageUrl() == null): ?>
						<a href="#" class="page-link disabled">Next</a>
					<?php else: ?>
						<a href="<?php echo e($dataDiklat->nextPageUrl()); ?>" class="page-link">Next</a>
					<?php endif; ?>
				</li>
				<li class="page-item">
					<?php if($dataDiklat->url($dataDiklat->lastPage()) == null): ?>
						<a href="#" class="page-link disabled">Last</a>
					<?php else: ?>
						<a href="<?php echo e($dataDiklat->url($dataDiklat->lastPage())); ?>" class="page-link">Last</a>
					<?php endif; ?>
				</li>
			</ul>
		</div>
	</div>
</section>

<script>
	window.onload = () => {
		document.querySelectorAll('#data-diklat').forEach(el => {
			listDataDiklat.push({
				pemilik: el.getAttribute('data-pemilik'),
				namaDikalt: el.getAttribute('data-namaDiklat'),
				element: el 
			})
		})
		
		const serachInput = document.getElementById('search-input');
		document.getElementById('search-diklat').addEventListener('submit', ev => {
			ev.preventDefault()
			window.location.href = `/admin?q=${serachInput.value}`
		})
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>