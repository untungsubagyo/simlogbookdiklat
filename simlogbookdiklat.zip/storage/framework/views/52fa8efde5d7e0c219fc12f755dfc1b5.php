<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>View Guru</title>
</head>
<body>
<div class="container mt-5">
    <h1>View Guru</h1>
    <div class="card">
        <div class="card-header">
            <?php echo e($guru->name); ?>

        </div>
        <div class="card-body">
            <p><strong>Email:</strong> <?php echo e($guru->email); ?></p>
            <p><strong>Created At:</strong> <?php echo e($guru->created_at); ?></p>
            <p><strong>Updated At:</strong> <?php echo e($guru->updated_at); ?></p>
            <a href="<?php echo e(route('gurus.index')); ?>" class="btn btn-primary">Back to List</a>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/gurus/show.blade.php ENDPATH**/ ?>