<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Pangkat & Golongan</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Pangkat & Golongan</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section pangkat_golongan">
        <div class="col-lg-12">
            <a href="<?php echo e(route('golongan_guru.create')); ?>" class="btn btn-primary">Tambah</a>

            <?php if(session('success')): ?>
                <div class="alert alert-success mt-3">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <table class="table datatable table-stripped">
                <thead>
                    <tr>
                        <th>Golongan</th>
                        <th>Pangkat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($data->golongan); ?></td>
                            <td><?php echo e($data->pangkat); ?></td>
                            <td>
                                <form onsubmit="return confirm('Apakah Anda yakin?')"
                                    action="<?php echo e(route('golongan_guru.destroy', $data->id)); ?>" method="POST">
                                    <a href="<?php echo e(route('golongan_guru.edit', $data->id)); ?>" class="btn btn-warning">Edit</a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="text-center alert alert-danger">Data Golongan & Pangkat masih
                                Kosong</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.root-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/admin/golongan_guru/index.blade.php ENDPATH**/ ?>