<aside id="sidebar" class="sidebar">
   <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
         <a class="nav-link <?php echo e(Route::getCurrentRoute()->getName() == 'homePageGuru' ? 'active' : 'collapsed'); ?>" href="<?php echo e(route('homePageGuru')); ?>">
            <i class="bi bi-grid"></i>
            <span>Beranda</span>
         </a>
      </li>

      <li class="nav-item">
         <a class="nav-link  <?php echo e(Route::getCurrentRoute()->getName() == 'diklat.create' ? 'active' : 'collapsed'); ?>" href="<?php echo e(route('diklat.create')); ?>">
            <i class="bi bi-person"></i>
            <span>Tambah Diklat</span>
         </a>
      </li>
   </ul>
</aside><?php /**PATH D:\laragon\www\simlogbookdiklat\resources\views/pages/guru/sidebar.blade.php ENDPATH**/ ?>